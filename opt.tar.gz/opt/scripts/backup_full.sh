#!/bin/bash

# 1) Desarrollar un script de backup denominado “backup_full.sh”, y guardarlo en
# /opt/scripts.

# 2) El script debe backupear los directorios indicados con nombres que incluyan la
# fecha en formato ANSI (YYYMMDD). Por ejemplo, para /var/log, el archivo
# generado debería llamarse “log_bkp_20240302.tar.gz”

fechAnsi=$(date +%Y%m%d)

# 5) El script debe incluir una opción de ayuda (-help), para guiar al usuario en el uso del script.

ayuda() {
    echo "           _____       _____     "
    echo "      ,-'\`\`_.-'\` \\   / \`'-.__\`'-.    "
    echo "    ,\`   .'      |\`-'|      \`.   \`.   "
    echo "  ,\`    (    /\\  |   |  /\\    )    \`.  "
    echo " /       \`--'  \`-'   \`-'  \`--'       \\ "
    echo " |                                   | "
    echo " \\      .--.  ,--.   ,--.  ,--.      / "
    echo "  \`.   (    /\\ lt.\\ /    /\\    )   ,\` "
    echo "    \`._ \`--.___    V    ___.--' _,\`   "
    echo "       \`'----'\`         \`'----'\`     "
    echo "========================================================================="
    echo " MODO DE USO DE: backup_full.sh"
    echo "========================================================================="
    echo "Sintaxis obligatoria:"
    echo "  $0 <origen> <destino>"
    echo ""
    echo "Parámetros:"
    echo "  <origen>   Ruta absoluta del directorio que se desea respaldar."
    echo "  <destino>  Ruta absoluta del directorio donde se guardará el backup."
    echo ""
    echo "Opciones disponibles:"
    echo "  -help      Muestra esta pantalla de guía."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /www_dir /backup_dir"
    echo "========================================================================="
    exit 0
}

# 6) El script debe validar que los sistemas de archivos de origen y destino estén disponibles antes de ejecutar el backup.

validar_directorio() {
    if [[ -d "$1" ]]; then
        echo "El directorio de $2 [$1] está disponible."
    else
        echo "ERROR - El directorio de $2 [$1] no está disponible o no existe."
        exit 1
    fi
}

# 5) llama a la funcion de ayuda mediante el argumento -help

if [[ $1 == "-help" ]]; then
    ayuda
fi

# validacion de cant de argumentos

if [[ $# -ne 2 ]]; then
    echo "ERROR: Cantidad de argumentos inválida."
    echo "Use: $0 -help para ver la guía de uso."
    exit 1
fi

# 4) El script debe aceptar argumentos como origen (lo que se va a backupear) y
# destino (dónde se va a backupear)
# 6) Guardamos el argumento de origen (argumento posicional 1) y el de destino (argumento posicional 2) 

argOrigen=$1
argDestino=$2

# 6) Pasamos los argumentos guardados en variables como parametros de la función para hacer la validación

validar_directorio "$argOrigen" "origen"
validar_directorio "$argDestino" "destino"

# 2) El script debe backupear los directorios indicados con nombres que incluyan la
# fecha en formato ANSI (YYYMMDD). Por ejemplo, para /var/log, el archivo
# generado debería llamarse “log_bkp_20240302.tar.gz”

nombre_carpeta=$(basename "$argOrigen")

if [[ "$nombre_carpeta" == "log" ]]; then
    nombre_archivo="log_bkp_${fechAnsi}.tar.gz"
else
    nombre_archivo="${nombre_carpeta}_bkp_${fechAnsi}.tar.gz"
fi

# 3) Los backups generados deben almacenarse en la partición que tiene montado el
# directorio /backup_dir.(Este directorio se debe pasar como argumento de destino)

echo "Iniciando proceso de backup..."
tar -czPf "$argDestino/$nombre_archivo" "$argOrigen"

# validacion manual (para que nos indique si anduvo el script al ejecutarlo)

if [[ $? -eq 0 ]]; then
    echo "¡Backup finalizado con ÉXITO en $argDestino/$nombre_archivo!"
    exit 0
else
    echo "ERROR: Ocurrió un problema al intentar compilar el archivo tar.gz"
    exit 1
fi
